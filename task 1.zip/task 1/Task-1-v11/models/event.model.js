const mongoose = require('mongoose');

const eventSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, 'Please provide an event title'],
      trim: true
    },
    description: {
      type: String,
      required: false
    },
    date: {
      type: Date,
      required: [true, 'Please provide an event date']
    },
    location: {
      type: String,
      required: [true, 'Please provide an event location']
    },
    capacity: {
      type: Number,
      required: [true, 'Please provide the event capacity'],
      min: [1, 'Capacity must be at least 1']
    },
    category: {
      type: String,
      enum: {
        values: ['academic', 'social', 'sports', 'career', 'other'],
        message: '{VALUE} is not a valid category'
      },
      default: 'other'
    },
    isFree: {
      type: Boolean,
      default: true
    },
    price: {
      type: Number,
      min: [0, 'Price cannot be negative'],
      default: 0
    }
  },
  { timestamps: true }
);

const getEvents = async (req, res) => {
  try {
    const filter = {};

    // only apply the conditions the client actually sent
    if (req.query.category) {
      filter.category = req.query.category;
    }

    // query values arrive as text ("true"/"false"), so convert to a real boolean
    if (req.query.isFree !== undefined) {
      filter.isFree = req.query.isFree === 'true';
    }

    const events = await Event.find(filter); // empty filter = every event
    res.status(200).json(events);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const getUpcomingEvents = async (req, res) => {
  try {
    const events = await Event.find({ date: { $gt: new Date() } }).sort({ date: 1 });
    res.status(200).json(events);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
// Same title can't be scheduled twice on the same date
eventSchema.index({ title: 1, date: 1 }, { unique: true });

module.exports = mongoose.model('Event', eventSchema);