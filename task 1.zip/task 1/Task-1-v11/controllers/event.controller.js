const Event = require('../models/event.model.js');

// Shared error handler
const handleError = (error, res) => {
  if (error.code === 11000) {
    return res.status(409).json({ message: 'Event already exists' });
  }
  if (error.name === 'ValidationError') {
    return res.status(400).json({ message: error.message });
  }
  if (error.name === 'CastError') {
    return res.status(400).json({ message: 'Invalid event id' });
  }
  return res.status(500).json({ message: error.message });
};

const getEvents = async (req, res) => {
  try {
    const filter = {};

    if (req.query.category) {
      filter.category = req.query.category;
    }
    if (req.query.isFree !== undefined) {
      filter.isFree = req.query.isFree === 'true';
    }

    const events = await Event.find(filter);
    res.status(200).json(events);
  } catch (error) {
    handleError(error, res);
  }
};

const getUpcomingEvents = async (req, res) => {
  try {
    const events = await Event.find({ date: { $gt: new Date() } }).sort({ date: 1 });
    res.status(200).json(events);
  } catch (error) {
    handleError(error, res);
  }
};

const getEventById = async (req, res) => {
  try {
    const { id } = req.params;
    const event = await Event.findById(id);
    if (!event) {
      return res.status(404).json({ message: 'Event not found' });
    }
    res.status(200).json(event);
  } catch (error) {
    handleError(error, res);
  }
};

const createEvent = async (req, res) => {
  try {
    const event = await Event.create(req.body);
    res.status(201).json(event);
  } catch (error) {
    handleError(error, res);
  }
};

const updateEvent = async (req, res) => {
  try {
    const { id } = req.params;
    const event = await Event.findByIdAndUpdate(id, req.body, {
      new: true,
      runValidators: true
    });
    if (!event) {
      return res.status(404).json({ message: 'Event not found' });
    }
    res.status(200).json(event);
  } catch (error) {
    handleError(error, res);
  }
};

const deleteEvent = async (req, res) => {
  try {
    const { id } = req.params;
    const event = await Event.findByIdAndDelete(id);
    if (!event) {
      return res.status(404).json({ message: 'Event not found' });
    }
    res.status(200).json({ message: 'Event deleted successfully' });
  } catch (error) {
    handleError(error, res);
  }
};

module.exports = {
  getEvents,
  getUpcomingEvents,
  getEventById,
  createEvent,
  updateEvent,
  deleteEvent
};